const http = require('http');
const net = require('net');
const url = require('url');
const path = require('path');
const fs = require('fs');

const PORTA_PROXY = process.env.PROXY_PORT || 8080;
const PORTA_APP = process.env.PORT || 3000;
const HOST_NOTEBOOK = '192.168.137.1'; // IP do notebook visto pelos clientes

// IPs liberados após pagamento confirmado: Map<ip, dataExpiracao>
const ipsLiberados = new Map();

/**
 * Marca um IP como liberado até a data de expiração informada.
 * Chamado pelo sessionService quando o pagamento é confirmado.
 */
function liberarIp(ip, minutos) {
  const expiraEm = Date.now() + minutos * 60 * 1000;
  ipsLiberados.set(ip, expiraEm);
  console.log(`✅ LIBERADO no proxy: ${ip} por ${minutos} minutos`);

  setTimeout(() => {
    ipsLiberados.delete(ip);
    console.log(`⏹️ EXPIRADO no proxy: ${ip}`);
  }, minutos * 60 * 1000);
}

/**
 * Verifica se um IP está liberado neste momento.
 */
function estaLiberado(ip) {
  const expiraEm = ipsLiberados.get(ip);
  if (!expiraEm) return false;
  if (Date.now() > expiraEm) {
    ipsLiberados.delete(ip);
    return false;
  }
  return true;
}

/**
 * Extrai o IP real do cliente a partir da conexão.
 */
function obterIpCliente(req) {
  return (req.socket.remoteAddress || '').replace('::ffff:', '');
}

// --- Servidor proxy HTTP (porta 8080) ---
const servidorProxy = http.createServer((req, res) => {
  const ipCliente = obterIpCliente(req);

  if (estaLiberado(ipCliente)) {
    repassarParaInternet(req, res);
  } else {
    redirecionarParaPagamento(req, res);
  }
});

/**
 * Cliente ainda não pagou: qualquer site que ele tentar abrir
 * cai na página de pagamento do nosso próprio sistema.
 */
function redirecionarParaPagamento(req, res) {
  // Se já está tentando acessar o próprio app (porta 3000 via proxy), repassa direto
  const hostHeader = req.headers.host || '';
  if (hostHeader.includes(HOST_NOTEBOOK)) {
    repassarParaApp(req, res);
    return;
  }

  res.writeHead(302, { Location: `http://${HOST_NOTEBOOK}:${PORTA_APP}` });
  res.end();
}

/**
 * Repassa a requisição para o servidor de aplicação local (server.js, porta 3000),
 * informando o IP real do cliente via header X-Forwarded-For (o Express só vê
 * o IP do proxy, então sem isso o sistema não saberia quem realmente está pedindo).
 */
function repassarParaApp(req, res) {
  const ipCliente = obterIpCliente(req);

  const opcoes = {
    host: HOST_NOTEBOOK,
    port: PORTA_APP,
    path: req.url,
    method: req.method,
    headers: { ...req.headers, 'x-forwarded-for': ipCliente }
  };

  const requisicaoInterna = http.request(opcoes, (respostaInterna) => {
    res.writeHead(respostaInterna.statusCode, respostaInterna.headers);
    respostaInterna.pipe(res);
  });

  req.pipe(requisicaoInterna);
  requisicaoInterna.on('error', (erro) => {
    console.error('Erro ao repassar para o app:', erro.message);
    res.writeHead(502);
    res.end('Erro ao acessar o sistema.');
  });
}

/**
 * Cliente já liberado: repassa a requisição de verdade para o site
 * que ele está tentando acessar, agindo como proxy normal.
 */
function repassarParaInternet(req, res) {
  const destino = url.parse(req.url);
  const opcoes = {
    host: destino.hostname || req.headers.host,
    port: destino.port || 80,
    path: destino.path || req.url,
    method: req.method,
    headers: req.headers
  };

  const requisicaoExterna = http.request(opcoes, (respostaExterna) => {
    res.writeHead(respostaExterna.statusCode, respostaExterna.headers);
    respostaExterna.pipe(res);
  });

  req.pipe(requisicaoExterna);
  requisicaoExterna.on('error', (erro) => {
    console.error('Erro ao repassar para a internet:', erro.message);
    res.writeHead(502);
    res.end('Erro ao acessar o site solicitado.');
  });
}

// --- Suporte a HTTPS (CONNECT) ---
// Para clientes liberados, permite o túnel HTTPS normalmente.
// Para clientes não liberados, a conexão HTTPS é recusada
// (o celular detecta isso e abre a tela de login do Wi-Fi automaticamente).
servidorProxy.on('connect', (req, clientSocket, head) => {
  const ipCliente = (clientSocket.remoteAddress || '').replace('::ffff:', '');

  if (!estaLiberado(ipCliente)) {
    clientSocket.end('HTTP/1.1 403 Forbidden\r\n\r\n');
    return;
  }

  const [host, porta] = req.url.split(':');
  const socketDestino = net.connect(porta || 443, host, () => {
    clientSocket.write('HTTP/1.1 200 Connection Established\r\n\r\n');
    socketDestino.pipe(clientSocket);
    clientSocket.pipe(socketDestino);
  });

  socketDestino.on('error', () => clientSocket.end());
  clientSocket.on('error', () => socketDestino.end());
});

servidorProxy.listen(PORTA_PROXY, '0.0.0.0', () => {
  console.log(`✅ Proxy (portão de entrada) rodando na porta ${PORTA_PROXY}`);
});

module.exports = { liberarIp, estaLiberado };
