require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const path = require('path');

// Inicia também o servidor proxy (porteiro da internet) na porta 8080
require('./proxyServer');

const paymentsRoutes = require('./routes/payments');
const webhookRoutes = require('./routes/webhook');

const app = express();
const PORTA = process.env.PORT || 3000;
const PASTA_FRONTEND = path.join(__dirname, '../frontend');

app.use(helmet());
app.use(cors());
app.use(morgan('dev'));
app.use(express.json());

// Rotas da API
app.use('/api/payments', paymentsRoutes);
app.use('/webhook', webhookRoutes);

// Arquivos do frontend (HTML, CSS, JS)
app.use(express.static(PASTA_FRONTEND));

// Qualquer rota não reconhecida volta para a página principal
// (importante para o captive portal: qualquer endereço cai aqui)
app.get('*', (req, res) => {
  res.sendFile(path.join(PASTA_FRONTEND, 'index.html'));
});

// Tratamento de erros centralizado
app.use((err, req, res, next) => {
  console.error('❌ Erro:', err.message);
  res.status(500).json({ error: 'Erro interno no servidor' });
});

app.listen(PORTA, '0.0.0.0', () => {
  console.log(`✅ Sistema rodando na porta ${PORTA}`);
});
