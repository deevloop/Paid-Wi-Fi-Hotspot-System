const asaasApi = require('../config/asaas');

exports.createCustomer = async (data) => {
  try {
    const response = await asaasApi.post('/customers', {
      name: data.full_name,
      phone: data.phone,
      email: data.email || undefined,
      notificationDisabled: true
    });
    return response.data;
  } catch (error) {
    throw new Error(`Failed to create customer: ${error.message}`);
  }
};

exports.createPixPayment = async (customerId, amount, description) => {
  try {
    const payment = await asaasApi.post('/payments', {
      customer: customerId,
      billingType: 'PIX',
      value: amount,
      description: description,
      dueDate: new Date().toISOString().split('T')[0]
    });

    const qrCode = await asaasApi.get(`/payments/${payment.data.id}/pixQrCode`);

    return {
      ...payment.data,
      qrCodeImage: qrCode.data.encodedImage,
      pixCopyPaste: qrCode.data.payload
    };
  } catch (error) {
    throw new Error(`Failed to generate PIX payment: ${error.message}`);
  }
};