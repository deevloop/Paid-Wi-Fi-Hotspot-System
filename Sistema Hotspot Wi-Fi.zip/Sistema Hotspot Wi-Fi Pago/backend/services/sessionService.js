const db = require('../config/db');
const firewallService = require('./firewallService');

exports.createSession = async (paymentId) => {
  const paymentData = await db.query(
    `SELECT p.user_id, p.ip_address, pl.duration_minutes FROM payments p
     JOIN plans pl ON p.plan_id = pl.id WHERE p.id = $1`,
    [paymentId]
  );

  if (paymentData.rows.length === 0) throw new Error('Payment not found');
  const { user_id, ip_address, duration_minutes } = paymentData.rows[0];

  const expiresAt = new Date();
  expiresAt.setMinutes(expiresAt.getMinutes() + duration_minutes);

  const sessionResult = await db.query(
    `INSERT INTO sessions (user_id, payment_id, expires_at, status)
     VALUES ($1, $2, $3, 'ACTIVE') RETURNING *`,
    [user_id, paymentId, expiresAt]
  );

  // Libera o acesso de fato no firewall, usando o IP salvo no momento do pagamento
  if (ip_address) {
    await firewallService.liberarAcesso(ip_address, duration_minutes);
  } else {
    console.warn(`⚠️ Pagamento ${paymentId} sem IP registrado — acesso NÃO foi liberado automaticamente.`);
  }

  return sessionResult.rows[0];
};