const proxyServer = require('../proxyServer');

/**
 * Libera o acesso à internet para um IP específico, através do
 * proxy interno (proxyServer.js), por um determinado tempo em minutos.
 *
 * Substitui a tentativa anterior via netsh advfirewall: o Firewall do
 * Windows não filtra tráfego roteado/NAT de outros dispositivos, então
 * o controle de acesso é feito aqui, em nível de aplicação (proxy).
 */
async function liberarAcesso(ip, minutos) {
  proxyServer.liberarIp(ip, minutos);
  return true;
}

module.exports = { liberarAcesso };
