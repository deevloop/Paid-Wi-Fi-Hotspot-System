const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);

// Prefixo usado no nome das regras, para identificar e remover depois
const PREFIXO_REGRA = 'WifiPago_';

// IP do notebook na interface conectada ao N301 (lado dos clientes)
// Esse é o "localip" usado para restringir as regras a essa rede específica
const IP_LOCAL_CLIENTES = '192.168.137.1';

/**
 * Libera o acesso à internet para um IP específico, criando uma regra
 * de exceção no Firewall do Windows, e agenda o bloqueio automático
 * quando o tempo contratado expirar.
 *
 * Pré-requisito: o Firewall do Windows precisa estar, por padrão,
 * BLOQUEANDO o tráfego de saída da rede dos clientes (ver guia de
 * configuração de rede). Esta função cria a exceção (permissão).
 */
async function liberarAcesso(ip, minutos) {
  const nomeRegra = `${PREFIXO_REGRA}${ip}`;

  try {
    // Remove regra antiga do mesmo IP, se existir (evita duplicar)
    await removerRegra(nomeRegra).catch(() => {});

    // Cria regra de permissão para esse IP, restrita ao lado da rede dos clientes
    const comando = `netsh advfirewall firewall add rule name="${nomeRegra}" dir=out localip=${IP_LOCAL_CLIENTES} remoteip=${ip} action=allow enable=yes`;
    await execPromise(comando);

    console.log(`✅ LIBERADO: ${ip} | Tempo: ${minutos} minutos`);

    // Agenda o bloqueio automático ao fim do tempo contratado
    setTimeout(() => {
      removerRegra(nomeRegra)
        .then(() => console.log(`⏹️ EXPIRADO: ${ip}`))
        .catch((erro) => console.error(`❌ Erro ao expirar ${ip}:`, erro.message));
    }, minutos * 60 * 1000);

    return true;
  } catch (erro) {
    console.error(`❌ Erro ao liberar ${ip}:`, erro.message);
    throw erro;
  }
}

/**
 * Remove a regra de liberação de um IP, bloqueando o acesso novamente.
 */
async function removerRegra(nomeRegra) {
  const comando = `netsh advfirewall firewall delete rule name="${nomeRegra}"`;
  return execPromise(comando);
}

/**
 * Bloqueia manualmente um IP antes do tempo expirar (ex: ação administrativa).
 */
async function bloquearAcesso(ip) {
  const nomeRegra = `${PREFIXO_REGRA}${ip}`;
  await removerRegra(nomeRegra);
  console.log(`🚫 BLOQUEADO manualmente: ${ip}`);
}

module.exports = { liberarAcesso, bloquearAcesso };