const axios = require('axios');
require('dotenv').config();

const asaasApi = axios.create({
  baseURL: process.env.ASAAS_API_URL,
  headers: {
    'Content-Type': 'application/json',
    'access_token': process.env.ASAAS_API_KEY
  }
});

module.exports = asaasApi;