const db = require('../config/db');
const asaasService = require('./asaasService');

exports.generatePayment = async (data) => {
  const { plan_id, full_name, phone, email, ip_address } = data;

  const planResult = await db.query(
    'SELECT * FROM plans WHERE id = $1 AND is_active = true',
    [plan_id]
  );

  if (planResult.rows.length === 0) throw new Error('Plan not found');
  const plan = planResult.rows[0];

  let userResult = await db.query('SELECT * FROM users WHERE phone = $1', [phone]);
  if (userResult.rows.length === 0) {
    userResult = await db.query(
      'INSERT INTO users (full_name, phone, email) VALUES ($1, $2, $3) RETURNING *',
      [full_name, phone, email]
    );
  }
  const user = userResult.rows[0];

  const asaasCustomer = await asaasService.createCustomer({ full_name, phone, email });
  const asaasPayment = await asaasService.createPixPayment(asaasCustomer.id, plan.price, `Wi-Fi: ${plan.name}`);

  const paymentResult = await db.query(
    `INSERT INTO payments (user_id, plan_id, asaas_payment_id, amount, ip_address, status)
     VALUES ($1, $2, $3, $4, $5, 'PENDING') RETURNING *`,
    [user.id, plan.id, asaasPayment.id, plan.price, ip_address]
  );

  return {
    id: paymentResult.rows[0].id,
    qrCodeBase64: asaasPayment.qrCodeImage,
    pixCopyPaste: asaasPayment.pixCopyPaste,
    amount: asaasPayment.value,
    status: 'PENDING'
  };
};

exports.updatePaymentStatus = async (asaasPaymentId, newStatus) => {
  const result = await db.query(
    `UPDATE payments SET status = $1, paid_at = CASE WHEN $1 = 'PAID' THEN NOW() ELSE paid_at END
     WHERE asaas_payment_id = $2 RETURNING *`,
    [newStatus, asaasPaymentId]
  );
  return result.rows[0];
};