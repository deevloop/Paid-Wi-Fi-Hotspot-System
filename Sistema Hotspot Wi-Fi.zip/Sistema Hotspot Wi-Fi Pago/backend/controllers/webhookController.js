const paymentService = require('../services/paymentService');
const sessionService = require('../services/sessionService');

exports.receiveEvent = async (req, res, next) => {
  try {
    const { event, payment } = req.body;
    const receivedSecret = req.headers['x-webhook-secret'];

    if (receivedSecret !== process.env.WEBHOOK_SECRET) {
      return res.sendStatus(403);
    }

    if (event === 'PAYMENT_RECEIVED' || event === 'PAYMENT_CONFIRMED') {
      const updatedPayment = await paymentService.updatePaymentStatus(payment.id, 'PAID');
      await sessionService.createSession(updatedPayment.id);
      console.log(`✅ Payment confirmed, access granted: ${payment.id}`);
    }

    res.sendStatus(200);
  } catch (error) {
    next(error);
  }
};