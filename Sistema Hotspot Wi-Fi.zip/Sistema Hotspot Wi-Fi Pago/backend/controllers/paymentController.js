const db = require('../config/db');
const paymentService = require('../services/paymentService');

exports.generate = async (req, res, next) => {
  try {
    // Captura o IP real do dispositivo do cliente, mesmo atrás de proxy/NAT
    const ipCliente = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || '')
      .split(',')[0]
      .trim()
      .replace('::ffff:', '');

    const result = await paymentService.generatePayment({ ...req.body, ip_address: ipCliente });
    res.status(201).json(result);
  } catch (error) {
    next(error);
  }
};

exports.checkStatus = async (req, res, next) => {
  try {
    const payment = await db.query(
      'SELECT status FROM payments WHERE id = $1',
      [req.params.id]
    );
    if (payment.rows.length === 0) {
      return res.status(404).json({ error: 'Payment not found' });
    }
    res.json({ status: payment.rows[0].status });
  } catch (error) {
    next(error);
  }
};