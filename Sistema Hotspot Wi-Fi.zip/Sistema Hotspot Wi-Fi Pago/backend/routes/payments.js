const express = require('express');
const router = express.Router();
const controller = require('../controllers/paymentController');

router.post('/generate', controller.generate);
router.get('/:id/status', controller.checkStatus);

module.exports = router;