const express = require('express');
const router = express.Router();
const controller = require('../controllers/webhookController');

router.post('/asaas', controller.receiveEvent);

module.exports = router;