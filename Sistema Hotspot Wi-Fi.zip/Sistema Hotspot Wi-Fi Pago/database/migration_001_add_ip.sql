-- Rodar este comando manualmente no banco já existente
-- (não precisa rodar se for instalação nova com schema.sql atualizado)
ALTER TABLE payments ADD COLUMN IF NOT EXISTS ip_address VARCHAR(45);
