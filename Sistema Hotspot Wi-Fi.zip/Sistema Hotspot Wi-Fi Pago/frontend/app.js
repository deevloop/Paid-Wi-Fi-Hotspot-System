let selectedPlan = null;
let currentPayment = null;

function showScreen(id) {
    document.querySelectorAll('.screen').forEach(s => s.classList.add('hidden'));
    document.getElementById(id).classList.remove('hidden');
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function selectPlan(id) {
    const plans = [
        { id: 1, name: '1 Hora', price: 'R$ 5,00', duration: '60 minutos' },
        { id: 2, name: '2 Horas', price: 'R$ 8,00', duration: '120 minutos' },
        { id: 3, name: '5 Horas', price: 'R$ 15,00', duration: '300 minutos' },
        { id: 4, name: '1 Dia', price: 'R$ 30,00', duration: '24 horas' },
        { id: 5, name: '1 Mês', price: 'R$ 120,00', duration: '30 dias' }
    ];
    selectedPlan = plans.find(p => p.id === id);

    document.getElementById('summary-box').innerHTML = `
        <h4>Resumo do pedido</h4>
        <p><strong>Plano:</strong> ${selectedPlan.name}</p>
        <p><strong>Validade:</strong> ${selectedPlan.duration}</p>
        <p><strong>Valor:</strong> ${selectedPlan.price}</p>
    `;
    showScreen('checkout-screen');
}

function goBack() {
    if (currentPayment) {
        showScreen('checkout-screen');
    } else {
        showScreen('home');
    }
}

document.getElementById('user-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const data = {
        plan_id: selectedPlan.id,
        full_name: document.getElementById('fullname').value.trim(),
        phone: document.getElementById('phone').value.replace(/\D/g, ''),
        email: document.getElementById('email').value.trim() || null
    };

    try {
        const res = await fetch('/api/payments/generate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        if (!res.ok) throw new Error('Não foi possível gerar o pagamento. Tente novamente.');
        const result = await res.json();
        currentPayment = result;
        document.getElementById('qrcode-area').innerHTML = `<img src="${result.qrCodeBase64}" alt="QR Code PIX" width="200" height="200">`;
        document.getElementById('pix-code').value = result.pixCopyPaste;
        showScreen('payment-screen');
        checkPaymentStatus(result.id);
    } catch (err) {
        alert('Erro: ' + err.message);
    }
});

function copyPix() {
    const input = document.getElementById('pix-code');
    input.select();
    document.execCommand('copy');
    alert('✅ Código copiado com sucesso!');
}

async function checkPaymentStatus(paymentId) {
    const interval = setInterval(async () => {
        try {
            const res = await fetch(`/api/payments/${paymentId}/status`);
            const data = await res.json();
            const statusBox = document.getElementById('status-area');
            if (data.status === 'PAID') {
                statusBox.textContent = '✅ Pagamento confirmado! Acesso liberado.';
                statusBox.style.color = '#22c55e';
                clearInterval(interval);
            }
        } catch (err) {
            console.log('Aguardando confirmação...');
        }
    }, 5000);
}